// BUGGY VERSION
@Entity
public class Patient {
    @OneToMany // BUG: missing mappedBy
    private List<Appointment> appointments;
}
