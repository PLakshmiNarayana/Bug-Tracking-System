BUG 1: Wrong JPA mapping
File: Patient.java
Problem: Missing mappedBy attribute in @OneToMany
