// SOLVED VERSION
@Entity
public class Patient {
    @OneToMany(mappedBy="patient")
    private List<Appointment> appointments;
}
