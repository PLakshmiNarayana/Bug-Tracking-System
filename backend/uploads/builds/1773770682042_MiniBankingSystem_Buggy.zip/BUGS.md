BUG 1: Incorrect balance calculation
File: AccountService.java
Buggy: balance + amount
Correct: balance - amount
