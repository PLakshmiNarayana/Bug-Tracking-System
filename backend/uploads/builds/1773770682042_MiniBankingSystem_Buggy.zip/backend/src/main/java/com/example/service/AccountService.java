// BUGGY VERSION
public double withdraw(double balance, double amount){
    return balance + amount; // BUG: should subtract
}
