BUG 1: Wrong total price calculation
File: OrderService.java
