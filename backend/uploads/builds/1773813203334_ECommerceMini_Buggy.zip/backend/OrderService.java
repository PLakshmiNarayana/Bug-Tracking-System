// BUGGY VERSION
public double total(double price, int qty){
   return price * qty + price; // BUG: extra price added
}
